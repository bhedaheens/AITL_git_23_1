package com.allintheloop.Volly;


/**
 * Created by admin on 2/28/2015.
 */
public interface VolleyInterface {
    void getVolleyRequestResponse(VolleyRequestResponse volleyResponse);
}
