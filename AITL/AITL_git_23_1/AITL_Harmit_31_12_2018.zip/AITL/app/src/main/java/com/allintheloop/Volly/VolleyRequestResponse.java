package com.allintheloop.Volly;

/**
 * Created by admin on 2/25/2015.
 */
public class VolleyRequestResponse {

    public String output;
    public int type;

    public VolleyRequestResponse(String output, int type) {
        this.output = output;
        this.type = type;
    }
}
