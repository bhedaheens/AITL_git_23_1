package com.allintheloop.Bean;

/**
 * Created by Aiyaz on 7/12/16.
 */

public class PrivateSpeakerList
{
    String name,id;

    public PrivateSpeakerList(String name, String id) {
        this.name = name;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
