package com.allintheloop.Bean;

/**
 * Created by nteam on 16/8/16.
 */
public class IdArray {
    String id;

    public IdArray(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
