package com.allintheloop.Bean.Speaker;

public class SpeakerType {

    String event_id, speakerType, speakerTypeColor, speakerPosition, speakerTypeId;


    public SpeakerType() {
    }

    public String getEvent_id() {
        return event_id;
    }

    public void setEvent_id(String event_id) {
        this.event_id = event_id;
    }

    public String getSpeakerType() {
        return speakerType;
    }

    public void setSpeakerType(String speakerType) {
        this.speakerType = speakerType;
    }

    public String getSpeakerTypeColor() {
        return speakerTypeColor;
    }

    public void setSpeakerTypeColor(String speakerTypeColor) {
        this.speakerTypeColor = speakerTypeColor;
    }

    public String getSpeakerPosition() {
        return speakerPosition;
    }

    public void setSpeakerPosition(String speakerPosition) {
        this.speakerPosition = speakerPosition;
    }

    public String getSpeakerTypeId() {
        return speakerTypeId;
    }

    public void setSpeakerTypeId(String speakerTypeId) {
        this.speakerTypeId = speakerTypeId;
    }
}
