package com.allintheloop.Bean.PhotoFilter;

public class EventBusgetPhotoFilterData {
    public final String data;

    public EventBusgetPhotoFilterData(String data) {
        this.data = data;
    }

    public String getData() {
        return data;
    }
}
