package com.allintheloop.Bean.HomeData;

/**
 * Created by nteam on 22/10/16.
 */
public class DashboardIdArray {
    String id;

    public DashboardIdArray(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
