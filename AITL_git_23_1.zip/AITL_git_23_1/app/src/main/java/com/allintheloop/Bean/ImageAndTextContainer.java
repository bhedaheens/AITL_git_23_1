package com.allintheloop.Bean;

import android.graphics.Bitmap;

/**
 * Created by Aiyaz on 18/5/17.
 */

public interface ImageAndTextContainer {
    public String getText();

    public Bitmap getImage();
}
