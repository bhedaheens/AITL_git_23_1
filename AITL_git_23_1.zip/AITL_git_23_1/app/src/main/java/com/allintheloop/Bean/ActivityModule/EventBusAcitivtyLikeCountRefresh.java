package com.allintheloop.Bean.ActivityModule;

public class EventBusAcitivtyLikeCountRefresh {
    public final String data;

    public EventBusAcitivtyLikeCountRefresh(String data) {
        this.data = data;
    }
}
