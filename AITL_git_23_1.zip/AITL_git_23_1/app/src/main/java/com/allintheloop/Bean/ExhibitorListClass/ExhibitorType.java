package com.allintheloop.Bean.ExhibitorListClass;

/**
 * Created by nteam on 7/11/17.
 */

public class ExhibitorType {

    String event_id, exhibitorId, exhibitorType, exhibitorTypeColor, parentCategoryId, productCategoryId;

    public ExhibitorType() {

    }

    public String getEvent_id() {
        return event_id;
    }

    public void setEvent_id(String event_id) {
        this.event_id = event_id;
    }

    public String getExhibitorId() {
        return exhibitorId;
    }

    public void setExhibitorId(String exhibitorId) {
        this.exhibitorId = exhibitorId;
    }

    public String getExhibitorType() {
        return exhibitorType;
    }

    public void setExhibitorType(String exhibitorType) {
        this.exhibitorType = exhibitorType;
    }

    public String getExhibitorTypeColor() {
        return exhibitorTypeColor;
    }

    public void setExhibitorTypeColor(String exhibitorTypeColor) {
        this.exhibitorTypeColor = exhibitorTypeColor;
    }

    public String getParentCategoryId() {
        return parentCategoryId;
    }

    public void setParentCategoryId(String parentCategoryId) {
        this.parentCategoryId = parentCategoryId;
    }

    public String getProductCategoryId() {
        return productCategoryId;
    }

    public void setProductCategoryId(String productCategoryId) {
        this.productCategoryId = productCategoryId;
    }
}
