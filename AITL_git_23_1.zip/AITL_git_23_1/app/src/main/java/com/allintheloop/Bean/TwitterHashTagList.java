package com.allintheloop.Bean;

/**
 * Created by Aiyaz on 15/5/17.
 */

public class TwitterHashTagList {
    String name;

    public TwitterHashTagList(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
