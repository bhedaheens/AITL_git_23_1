package com.allintheloop.Bean;

/**
 * Created by nteam on 1/7/16.
 */
public class PrivateMessage_Sppiner {
    String id, name;

    public PrivateMessage_Sppiner(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
