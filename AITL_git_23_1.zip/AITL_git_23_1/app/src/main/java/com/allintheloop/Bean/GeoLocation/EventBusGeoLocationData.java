package com.allintheloop.Bean.GeoLocation;

public class EventBusGeoLocationData {
    public final String notificationData;

    public EventBusGeoLocationData(String notificationData) {
        this.notificationData = notificationData;
    }
}
