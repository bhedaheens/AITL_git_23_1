package com.allintheloop.Bean.SponsorClass;

/**
 * Created by nteam on 30/11/17.
 */

public class SponsorType {
    String event_id, sponsorType, sponsorTypeColor, sponsorPosition, sponsorTypeId;


    public SponsorType() {
    }

    public String getEvent_id() {
        return event_id;
    }

    public void setEvent_id(String event_id) {
        this.event_id = event_id;
    }

    public String getSponsorType() {
        return sponsorType;
    }

    public void setSponsorType(String sponsorType) {
        this.sponsorType = sponsorType;
    }

    public String getSponsorTypeColor() {
        return sponsorTypeColor;
    }

    public void setSponsorTypeColor(String sponsorTypeColor) {
        this.sponsorTypeColor = sponsorTypeColor;
    }

    public String getSponsorPosition() {
        return sponsorPosition;
    }

    public void setSponsorPosition(String sponsorPosition) {
        this.sponsorPosition = sponsorPosition;
    }

    public String getSponsorTypeId() {
        return sponsorTypeId;
    }

    public void setSponsorTypeId(String sponsorTypeId) {
        this.sponsorTypeId = sponsorTypeId;
    }
}
